# Nakshatra Dashboard

A beautiful Vedic astrology app that shows the current Nakshatra (lunar mansion) with favorable/unfavorable indicators.

## Features
- 🌙 Real-time Nakshatra calculation
- 🟢 Green indicator for favorable Nakshatras (Pushya, Rohini, Anuradha, Uttara Phalguni, Revati)
- 🔴 Red indicator for unfavorable Nakshatras
- 📱 Installable as Progressive Web App
- 🔒 Secure HTTPS connection
- 📴 Works offline after first load

## How to Deploy on GitHub Pages

1. Create a new repository named `nakshatra`
2. Upload both `index.html` and `manifest.json` files
3. Go to Settings → Pages
4. Set Source to `main` branch
5. Your app will be live at: `https://yourusername.github.io/nakshatra`

## Install on Mobile

Once deployed, visit the URL on your mobile device and tap "Install app" or "Add to Home screen" in your browser.

## Privacy

- No data collection
- No external API calls
- All calculations performed locally
- No tracking or analytics

---

Made with ❤️ for Vedic Astrology enthusiasts
